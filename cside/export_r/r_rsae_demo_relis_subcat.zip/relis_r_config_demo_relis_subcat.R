source('relis_r_lib_demo_relis_subcat.R') # Replace this with the name of your imported library file

# The following lines consist of all the tests/plots corresponding to each category. Uncomment the required lines. 

# Descriptive statistics

# Frequency tables~Descriptive stats(Nominal variables)
# desc_distr_vector[['Cocoa.level']]
# desc_distr_vector[['Variety']]
# desc_distr_vector[['Variety.Level.1']]
# desc_distr_vector[['Variety.Level.2']]
# desc_distr_vector[['Venue']]
# desc_distr_vector[['Search.Type']]

# Bar Plots~Descriptive stats(Nominal variables)
# bar_plot_vector[['Cocoa.level']]
# bar_plot_vector[['Variety']]
# bar_plot_vector[['Variety.Level.1']]
# bar_plot_vector[['Variety.Level.2']]
# bar_plot_vector[['Venue']]
# bar_plot_vector[['Search.Type']]

# Statistics~Descriptive stats(Continuous variables)
# statistics_vector[['Publication.year']]

# Box Plots~Descriptive stats(Continuous variables)
# box_plot_vector[['Publication.year']]

# Violin Plots~Descriptive stats(Continuous variables)
# violin_plot_vector[['Publication.year']]

#######################################################################################

# Evolution statistics

# Frequency tables~Evolution stats(Nominal variables)
# evo_distr_vector[['Cocoa.level']]
# evo_distr_vector[['Variety']]
# evo_distr_vector[['Variety.Level.1']]
# evo_distr_vector[['Variety.Level.2']]
# evo_distr_vector[['Venue']]
# evo_distr_vector[['Search.Type']]

# Evolution Plots~Evolution stats(Nominal variables)
# evolution_plot_vector[['Cocoa.level']]
# evolution_plot_vector[['Variety']]
# evolution_plot_vector[['Variety.Level.1']]
# evolution_plot_vector[['Variety.Level.2']]
# evolution_plot_vector[['Venue']]
# evolution_plot_vector[['Search.Type']]

#######################################################################################

# Comparative statistics
# Frequency Tables~Comparative stats(Nominal variables)
# comp_distr_vector[['Cocoa.level']][['Variety']]
# comp_distr_vector[['Cocoa.level']][['Variety.Level.1']]
# comp_distr_vector[['Cocoa.level']][['Variety.Level.2']]
# comp_distr_vector[['Cocoa.level']][['Venue']]
# comp_distr_vector[['Cocoa.level']][['Search.Type']]
# comp_distr_vector[['Variety']][['Cocoa.level']]
# comp_distr_vector[['Variety']][['Variety.Level.1']]
# comp_distr_vector[['Variety']][['Variety.Level.2']]
# comp_distr_vector[['Variety']][['Venue']]
# comp_distr_vector[['Variety']][['Search.Type']]
# comp_distr_vector[['Variety.Level.1']][['Cocoa.level']]
# comp_distr_vector[['Variety.Level.1']][['Variety']]
# comp_distr_vector[['Variety.Level.1']][['Variety.Level.2']]
# comp_distr_vector[['Variety.Level.1']][['Venue']]
# comp_distr_vector[['Variety.Level.1']][['Search.Type']]
# comp_distr_vector[['Variety.Level.2']][['Cocoa.level']]
# comp_distr_vector[['Variety.Level.2']][['Variety']]
# comp_distr_vector[['Variety.Level.2']][['Variety.Level.1']]
# comp_distr_vector[['Variety.Level.2']][['Venue']]
# comp_distr_vector[['Variety.Level.2']][['Search.Type']]
# comp_distr_vector[['Venue']][['Cocoa.level']]
# comp_distr_vector[['Venue']][['Variety']]
# comp_distr_vector[['Venue']][['Variety.Level.1']]
# comp_distr_vector[['Venue']][['Variety.Level.2']]
# comp_distr_vector[['Venue']][['Search.Type']]
# comp_distr_vector[['Search.Type']][['Cocoa.level']]
# comp_distr_vector[['Search.Type']][['Variety']]
# comp_distr_vector[['Search.Type']][['Variety.Level.1']]
# comp_distr_vector[['Search.Type']][['Variety.Level.2']]
# comp_distr_vector[['Search.Type']][['Venue']]

# Stacked Bar Plots~Comparative stats(Nominal variables)
# stacked_bar_plot_vector[['Cocoa.level']][['Variety']]
# stacked_bar_plot_vector[['Cocoa.level']][['Variety.Level.1']]
# stacked_bar_plot_vector[['Cocoa.level']][['Variety.Level.2']]
# stacked_bar_plot_vector[['Cocoa.level']][['Venue']]
# stacked_bar_plot_vector[['Cocoa.level']][['Search.Type']]
# stacked_bar_plot_vector[['Variety']][['Cocoa.level']]
# stacked_bar_plot_vector[['Variety']][['Variety.Level.1']]
# stacked_bar_plot_vector[['Variety']][['Variety.Level.2']]
# stacked_bar_plot_vector[['Variety']][['Venue']]
# stacked_bar_plot_vector[['Variety']][['Search.Type']]
# stacked_bar_plot_vector[['Variety.Level.1']][['Cocoa.level']]
# stacked_bar_plot_vector[['Variety.Level.1']][['Variety']]
# stacked_bar_plot_vector[['Variety.Level.1']][['Variety.Level.2']]
# stacked_bar_plot_vector[['Variety.Level.1']][['Venue']]
# stacked_bar_plot_vector[['Variety.Level.1']][['Search.Type']]
# stacked_bar_plot_vector[['Variety.Level.2']][['Cocoa.level']]
# stacked_bar_plot_vector[['Variety.Level.2']][['Variety']]
# stacked_bar_plot_vector[['Variety.Level.2']][['Variety.Level.1']]
# stacked_bar_plot_vector[['Variety.Level.2']][['Venue']]
# stacked_bar_plot_vector[['Variety.Level.2']][['Search.Type']]
# stacked_bar_plot_vector[['Venue']][['Cocoa.level']]
# stacked_bar_plot_vector[['Venue']][['Variety']]
# stacked_bar_plot_vector[['Venue']][['Variety.Level.1']]
# stacked_bar_plot_vector[['Venue']][['Variety.Level.2']]
# stacked_bar_plot_vector[['Venue']][['Search.Type']]
# stacked_bar_plot_vector[['Search.Type']][['Cocoa.level']]
# stacked_bar_plot_vector[['Search.Type']][['Variety']]
# stacked_bar_plot_vector[['Search.Type']][['Variety.Level.1']]
# stacked_bar_plot_vector[['Search.Type']][['Variety.Level.2']]
# stacked_bar_plot_vector[['Search.Type']][['Venue']]

# Grouped Bar Plots~Comparative stats(Nominal variables)
# grouped_bar_plot_vector[['Cocoa.level']][['Variety']]
# grouped_bar_plot_vector[['Cocoa.level']][['Variety.Level.1']]
# grouped_bar_plot_vector[['Cocoa.level']][['Variety.Level.2']]
# grouped_bar_plot_vector[['Cocoa.level']][['Venue']]
# grouped_bar_plot_vector[['Cocoa.level']][['Search.Type']]
# grouped_bar_plot_vector[['Variety']][['Cocoa.level']]
# grouped_bar_plot_vector[['Variety']][['Variety.Level.1']]
# grouped_bar_plot_vector[['Variety']][['Variety.Level.2']]
# grouped_bar_plot_vector[['Variety']][['Venue']]
# grouped_bar_plot_vector[['Variety']][['Search.Type']]
# grouped_bar_plot_vector[['Variety.Level.1']][['Cocoa.level']]
# grouped_bar_plot_vector[['Variety.Level.1']][['Variety']]
# grouped_bar_plot_vector[['Variety.Level.1']][['Variety.Level.2']]
# grouped_bar_plot_vector[['Variety.Level.1']][['Venue']]
# grouped_bar_plot_vector[['Variety.Level.1']][['Search.Type']]
# grouped_bar_plot_vector[['Variety.Level.2']][['Cocoa.level']]
# grouped_bar_plot_vector[['Variety.Level.2']][['Variety']]
# grouped_bar_plot_vector[['Variety.Level.2']][['Variety.Level.1']]
# grouped_bar_plot_vector[['Variety.Level.2']][['Venue']]
# grouped_bar_plot_vector[['Variety.Level.2']][['Search.Type']]
# grouped_bar_plot_vector[['Venue']][['Cocoa.level']]
# grouped_bar_plot_vector[['Venue']][['Variety']]
# grouped_bar_plot_vector[['Venue']][['Variety.Level.1']]
# grouped_bar_plot_vector[['Venue']][['Variety.Level.2']]
# grouped_bar_plot_vector[['Venue']][['Search.Type']]
# grouped_bar_plot_vector[['Search.Type']][['Cocoa.level']]
# grouped_bar_plot_vector[['Search.Type']][['Variety']]
# grouped_bar_plot_vector[['Search.Type']][['Variety.Level.1']]
# grouped_bar_plot_vector[['Search.Type']][['Variety.Level.2']]
# grouped_bar_plot_vector[['Search.Type']][['Venue']]

# Bubble Charts~Comparative stats(Nominal variables)
# bubble_chart_vector[['Cocoa.level']][['Variety']]
# bubble_chart_vector[['Cocoa.level']][['Variety.Level.1']]
# bubble_chart_vector[['Cocoa.level']][['Variety.Level.2']]
# bubble_chart_vector[['Cocoa.level']][['Venue']]
# bubble_chart_vector[['Cocoa.level']][['Search.Type']]
# bubble_chart_vector[['Variety']][['Cocoa.level']]
# bubble_chart_vector[['Variety']][['Variety.Level.1']]
# bubble_chart_vector[['Variety']][['Variety.Level.2']]
# bubble_chart_vector[['Variety']][['Venue']]
# bubble_chart_vector[['Variety']][['Search.Type']]
# bubble_chart_vector[['Variety.Level.1']][['Cocoa.level']]
# bubble_chart_vector[['Variety.Level.1']][['Variety']]
# bubble_chart_vector[['Variety.Level.1']][['Variety.Level.2']]
# bubble_chart_vector[['Variety.Level.1']][['Venue']]
# bubble_chart_vector[['Variety.Level.1']][['Search.Type']]
# bubble_chart_vector[['Variety.Level.2']][['Cocoa.level']]
# bubble_chart_vector[['Variety.Level.2']][['Variety']]
# bubble_chart_vector[['Variety.Level.2']][['Variety.Level.1']]
# bubble_chart_vector[['Variety.Level.2']][['Venue']]
# bubble_chart_vector[['Variety.Level.2']][['Search.Type']]
# bubble_chart_vector[['Venue']][['Cocoa.level']]
# bubble_chart_vector[['Venue']][['Variety']]
# bubble_chart_vector[['Venue']][['Variety.Level.1']]
# bubble_chart_vector[['Venue']][['Variety.Level.2']]
# bubble_chart_vector[['Venue']][['Search.Type']]
# bubble_chart_vector[['Search.Type']][['Cocoa.level']]
# bubble_chart_vector[['Search.Type']][['Variety']]
# bubble_chart_vector[['Search.Type']][['Variety.Level.1']]
# bubble_chart_vector[['Search.Type']][['Variety.Level.2']]
# bubble_chart_vector[['Search.Type']][['Venue']]

# Fisher's Exact Test~Comparative stats(Nominal variables)
# fisher_exact_test_vector[['Cocoa.level']][['Variety']]
# fisher_exact_test_vector[['Cocoa.level']][['Variety.Level.1']]
# fisher_exact_test_vector[['Cocoa.level']][['Variety.Level.2']]
# fisher_exact_test_vector[['Cocoa.level']][['Venue']]
# fisher_exact_test_vector[['Cocoa.level']][['Search.Type']]
# fisher_exact_test_vector[['Variety']][['Cocoa.level']]
# fisher_exact_test_vector[['Variety']][['Variety.Level.1']]
# fisher_exact_test_vector[['Variety']][['Variety.Level.2']]
# fisher_exact_test_vector[['Variety']][['Venue']]
# fisher_exact_test_vector[['Variety']][['Search.Type']]
# fisher_exact_test_vector[['Variety.Level.1']][['Cocoa.level']]
# fisher_exact_test_vector[['Variety.Level.1']][['Variety']]
# fisher_exact_test_vector[['Variety.Level.1']][['Variety.Level.2']]
# fisher_exact_test_vector[['Variety.Level.1']][['Venue']]
# fisher_exact_test_vector[['Variety.Level.1']][['Search.Type']]
# fisher_exact_test_vector[['Variety.Level.2']][['Cocoa.level']]
# fisher_exact_test_vector[['Variety.Level.2']][['Variety']]
# fisher_exact_test_vector[['Variety.Level.2']][['Variety.Level.1']]
# fisher_exact_test_vector[['Variety.Level.2']][['Venue']]
# fisher_exact_test_vector[['Variety.Level.2']][['Search.Type']]
# fisher_exact_test_vector[['Venue']][['Cocoa.level']]
# fisher_exact_test_vector[['Venue']][['Variety']]
# fisher_exact_test_vector[['Venue']][['Variety.Level.1']]
# fisher_exact_test_vector[['Venue']][['Variety.Level.2']]
# fisher_exact_test_vector[['Venue']][['Search.Type']]
# fisher_exact_test_vector[['Search.Type']][['Cocoa.level']]
# fisher_exact_test_vector[['Search.Type']][['Variety']]
# fisher_exact_test_vector[['Search.Type']][['Variety.Level.1']]
# fisher_exact_test_vector[['Search.Type']][['Variety.Level.2']]
# fisher_exact_test_vector[['Search.Type']][['Venue']]

# Shapiro Wilk's Correlation Test~Comparative stats(Continuous variables)
# shapiro_wilk_test_vector[['Publication.year']]

# Pearson's Correlation Test~Comparative stats(Continuous variables)

# Spearman's Correlation Test~Comparative stats(Continuous variables)

#######################################################################################