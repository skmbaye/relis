from relis_statistics_kernel import (
    NominalVariables, ContinuousVariables,
    desc_frequency_table, desc_statistics, desc_bar_plot, desc_box_plot, desc_violin_plot, 
    evo_plot, evo_frequency_table, comp_stacked_bar_plot, comp_grouped_bar_plot,
    comp_chi_squared_test, comp_spearman_cor_test, comp_frequency_table, comp_bubble_chart,
    comp_shapiro_wilk_test, comp_pearson_cor_test
)

#-- Environment version : 1.0.0

# Statistical tests for variable: 'cocoa_level'

#--Descriptive--#
# Name of test: [Frequency tables]
desc_frequency_table(NominalVariables.cocoa_level, False)
# Name of test: [Bar plots]
desc_bar_plot(NominalVariables.cocoa_level, False)

#--Evolutive--#
# Name of test: [Frequency tables]
evo_frequency_table(NominalVariables.cocoa_level, False)
# Name of test: [Evolution plots]
evo_plot(NominalVariables.cocoa_level, False)

#--Comparative--#
# Name of test: [Frequency tables]
comp_frequency_table(NominalVariables.cocoa_level, NominalVariables.variety, False)
comp_frequency_table(NominalVariables.cocoa_level, NominalVariables.variety_level_1, False)
comp_frequency_table(NominalVariables.cocoa_level, NominalVariables.variety_level_2, False)
# Name of test: [Stacked bar plots]
comp_stacked_bar_plot(NominalVariables.cocoa_level, NominalVariables.variety, False)
comp_stacked_bar_plot(NominalVariables.cocoa_level, NominalVariables.variety_level_1, False)
comp_stacked_bar_plot(NominalVariables.cocoa_level, NominalVariables.variety_level_2, False)
# Name of test: [Grouped bar plots]
comp_grouped_bar_plot(NominalVariables.cocoa_level, NominalVariables.variety, False)
comp_grouped_bar_plot(NominalVariables.cocoa_level, NominalVariables.variety_level_1, False)
comp_grouped_bar_plot(NominalVariables.cocoa_level, NominalVariables.variety_level_2, False)
# Name of test: [Bubble charts]
comp_bubble_chart(NominalVariables.cocoa_level, NominalVariables.variety, False)
comp_bubble_chart(NominalVariables.cocoa_level, NominalVariables.variety_level_1, False)
comp_bubble_chart(NominalVariables.cocoa_level, NominalVariables.variety_level_2, False)
# Name of test: [Chi-squared test]
comp_chi_squared_test(NominalVariables.cocoa_level, NominalVariables.variety, False)
comp_chi_squared_test(NominalVariables.cocoa_level, NominalVariables.variety_level_1, False)
comp_chi_squared_test(NominalVariables.cocoa_level, NominalVariables.variety_level_2, False)

# Statistical tests for variable: 'variety'

#--Descriptive--#
# Name of test: [Frequency tables]
desc_frequency_table(NominalVariables.variety, False)
# Name of test: [Bar plots]
desc_bar_plot(NominalVariables.variety, False)

#--Evolutive--#
# Name of test: [Frequency tables]
evo_frequency_table(NominalVariables.variety, False)
# Name of test: [Evolution plots]
evo_plot(NominalVariables.variety, False)

#--Comparative--#
# Name of test: [Frequency tables]
comp_frequency_table(NominalVariables.variety, NominalVariables.cocoa_level, False)
comp_frequency_table(NominalVariables.variety, NominalVariables.variety_level_1, False)
comp_frequency_table(NominalVariables.variety, NominalVariables.variety_level_2, False)
# Name of test: [Stacked bar plots]
comp_stacked_bar_plot(NominalVariables.variety, NominalVariables.cocoa_level, False)
comp_stacked_bar_plot(NominalVariables.variety, NominalVariables.variety_level_1, False)
comp_stacked_bar_plot(NominalVariables.variety, NominalVariables.variety_level_2, False)
# Name of test: [Grouped bar plots]
comp_grouped_bar_plot(NominalVariables.variety, NominalVariables.cocoa_level, False)
comp_grouped_bar_plot(NominalVariables.variety, NominalVariables.variety_level_1, False)
comp_grouped_bar_plot(NominalVariables.variety, NominalVariables.variety_level_2, False)
# Name of test: [Bubble charts]
comp_bubble_chart(NominalVariables.variety, NominalVariables.cocoa_level, False)
comp_bubble_chart(NominalVariables.variety, NominalVariables.variety_level_1, False)
comp_bubble_chart(NominalVariables.variety, NominalVariables.variety_level_2, False)
# Name of test: [Chi-squared test]
comp_chi_squared_test(NominalVariables.variety, NominalVariables.cocoa_level, False)
comp_chi_squared_test(NominalVariables.variety, NominalVariables.variety_level_1, False)
comp_chi_squared_test(NominalVariables.variety, NominalVariables.variety_level_2, False)

# Statistical tests for variable: 'variety_level_1'

#--Descriptive--#
# Name of test: [Frequency tables]
desc_frequency_table(NominalVariables.variety_level_1, False)
# Name of test: [Bar plots]
desc_bar_plot(NominalVariables.variety_level_1, False)

#--Evolutive--#
# Name of test: [Frequency tables]
evo_frequency_table(NominalVariables.variety_level_1, False)
# Name of test: [Evolution plots]
evo_plot(NominalVariables.variety_level_1, False)

#--Comparative--#
# Name of test: [Frequency tables]
comp_frequency_table(NominalVariables.variety_level_1, NominalVariables.cocoa_level, False)
comp_frequency_table(NominalVariables.variety_level_1, NominalVariables.variety, False)
comp_frequency_table(NominalVariables.variety_level_1, NominalVariables.variety_level_2, False)
# Name of test: [Stacked bar plots]
comp_stacked_bar_plot(NominalVariables.variety_level_1, NominalVariables.cocoa_level, False)
comp_stacked_bar_plot(NominalVariables.variety_level_1, NominalVariables.variety, False)
comp_stacked_bar_plot(NominalVariables.variety_level_1, NominalVariables.variety_level_2, False)
# Name of test: [Grouped bar plots]
comp_grouped_bar_plot(NominalVariables.variety_level_1, NominalVariables.cocoa_level, False)
comp_grouped_bar_plot(NominalVariables.variety_level_1, NominalVariables.variety, False)
comp_grouped_bar_plot(NominalVariables.variety_level_1, NominalVariables.variety_level_2, False)
# Name of test: [Bubble charts]
comp_bubble_chart(NominalVariables.variety_level_1, NominalVariables.cocoa_level, False)
comp_bubble_chart(NominalVariables.variety_level_1, NominalVariables.variety, False)
comp_bubble_chart(NominalVariables.variety_level_1, NominalVariables.variety_level_2, False)
# Name of test: [Chi-squared test]
comp_chi_squared_test(NominalVariables.variety_level_1, NominalVariables.cocoa_level, False)
comp_chi_squared_test(NominalVariables.variety_level_1, NominalVariables.variety, False)
comp_chi_squared_test(NominalVariables.variety_level_1, NominalVariables.variety_level_2, False)

# Statistical tests for variable: 'variety_level_2'

#--Descriptive--#
# Name of test: [Frequency tables]
desc_frequency_table(NominalVariables.variety_level_2, False)
# Name of test: [Bar plots]
desc_bar_plot(NominalVariables.variety_level_2, False)

#--Evolutive--#
# Name of test: [Frequency tables]
evo_frequency_table(NominalVariables.variety_level_2, False)
# Name of test: [Evolution plots]
evo_plot(NominalVariables.variety_level_2, False)

#--Comparative--#
# Name of test: [Frequency tables]
comp_frequency_table(NominalVariables.variety_level_2, NominalVariables.cocoa_level, False)
comp_frequency_table(NominalVariables.variety_level_2, NominalVariables.variety, False)
comp_frequency_table(NominalVariables.variety_level_2, NominalVariables.variety_level_1, False)
# Name of test: [Stacked bar plots]
comp_stacked_bar_plot(NominalVariables.variety_level_2, NominalVariables.cocoa_level, False)
comp_stacked_bar_plot(NominalVariables.variety_level_2, NominalVariables.variety, False)
comp_stacked_bar_plot(NominalVariables.variety_level_2, NominalVariables.variety_level_1, False)
# Name of test: [Grouped bar plots]
comp_grouped_bar_plot(NominalVariables.variety_level_2, NominalVariables.cocoa_level, False)
comp_grouped_bar_plot(NominalVariables.variety_level_2, NominalVariables.variety, False)
comp_grouped_bar_plot(NominalVariables.variety_level_2, NominalVariables.variety_level_1, False)
# Name of test: [Bubble charts]
comp_bubble_chart(NominalVariables.variety_level_2, NominalVariables.cocoa_level, False)
comp_bubble_chart(NominalVariables.variety_level_2, NominalVariables.variety, False)
comp_bubble_chart(NominalVariables.variety_level_2, NominalVariables.variety_level_1, False)
# Name of test: [Chi-squared test]
comp_chi_squared_test(NominalVariables.variety_level_2, NominalVariables.cocoa_level, False)
comp_chi_squared_test(NominalVariables.variety_level_2, NominalVariables.variety, False)
comp_chi_squared_test(NominalVariables.variety_level_2, NominalVariables.variety_level_1, False)

# Statistical tests for variable: 'publication_year'

#--Descriptive--#
# Name of test: [Statistics]
desc_statistics(ContinuousVariables.publication_year, False)
# Name of test: [Box plots]
desc_box_plot(ContinuousVariables.publication_year, False)
# Name of test: [Violin plots]
desc_violin_plot(ContinuousVariables.publication_year, False)
# Name of test: [Shapiro Wilk's correlation test]
comp_shapiro_wilk_test(ContinuousVariables.publication_year, False)

#--Comparative--#
# Name of test: [Pearson's correlation test]
# Name of test: [Spearman's correlation test]

input("Press enter to close...")